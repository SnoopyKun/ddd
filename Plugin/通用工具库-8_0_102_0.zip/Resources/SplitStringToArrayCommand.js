var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CommonUtilsCommand;
(function (CommonUtilsCommand) {
    var SplitStringToArrayCommand = /** @class */ (function (_super) {
        __extends(SplitStringToArrayCommand, _super);
        function SplitStringToArrayCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SplitStringToArrayCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            if (!commandSettings.ParamName) {
                return;
            }
            var splitString = this.evaluateFormula(commandSettings.SplitString);
            if (!splitString) {
                Forguncy.CommandHelper.setVariableValue(commandSettings.ParamName, null);
                return;
            }
            var separator = this.evaluateFormula(commandSettings.Separator);
            if (!separator) {
                separator = "";
            }
            var arr = splitString.split(separator);
            if (commandSettings.RemoveEmptyEntries) {
                arr = arr.filter(function (a) { return a !== null && a !== undefined && a !== ""; });
            }
            Forguncy.CommandHelper.setVariableValue(commandSettings.ParamName, arr);
        };
        return SplitStringToArrayCommand;
    }(Forguncy.Plugin.CommandBase));
    CommonUtilsCommand.SplitStringToArrayCommand = SplitStringToArrayCommand;
})(CommonUtilsCommand || (CommonUtilsCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("CommonUtilsCommand.SplitStringToArrayCommand, CommonUtilsCommand", CommonUtilsCommand.SplitStringToArrayCommand);
//# sourceMappingURL=SplitStringToArrayCommand.js.map