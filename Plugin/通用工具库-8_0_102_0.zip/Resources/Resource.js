var CommonUtilsCommand;
(function (CommonUtilsCommand) {
    var RS_CN = {
        Error_AddItemToArrayObjectCommand_ReturnParam_NeedsToBeAnArray: "参数错误：返回值不是数组对象"
    };
    var RS_EN = {
        Error_AddItemToArrayObjectCommand_ReturnParam_NeedsToBeAnArray: "Error Parameter: ReturnParam needs to be an array"
    };
    var RSHelper = /** @class */ (function () {
        function RSHelper() {
        }
        RSHelper.getRS = function () {
            switch (Forguncy.RS.Culture) {
                case "CN" /* Chinese */:
                    return RS_CN;
                case "EN" /* English */:
                case "JA" /* Japanese */:
                case "KR" /* Korean */:
                    return RS_EN;
                default:
                    return RS_CN;
            }
        };
        return RSHelper;
    }());
    CommonUtilsCommand.RSHelper = RSHelper;
})(CommonUtilsCommand || (CommonUtilsCommand = {}));
//# sourceMappingURL=Resource.js.map